package Covid19Tracker.Covid19Tracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Covid19TrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
